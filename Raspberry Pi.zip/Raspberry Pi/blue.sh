export DISPLAY=:1;
bluealsa-aplay 00:00:00:00:00:00 -d duplex &
