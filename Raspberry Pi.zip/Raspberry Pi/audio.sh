arecord -f dat | aplay -D duplex - &
