if test $(cat ~/.relays/incoming1) == 1
 	then
 		$(echo "+" > /dev/ttyS0)
 	else 
		$(echo "/" > /dev/ttyS0)
fi
if test $(cat ~/.relays/incoming2) == 1
 	then
 		$(echo 9 > /dev/ttyS0)
 	else 
		$(echo 0 > /dev/ttyS0)
fi
