$(echo "h" > /dev/ttyS0)
