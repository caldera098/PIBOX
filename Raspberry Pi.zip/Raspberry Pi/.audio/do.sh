if test $(cat ~/.audio/incoming) == 1
	then
		if test $(cat ~/.audio/status) == 1
			then
				echo "Already started."
			else
				$(arecord -r 48000 -f S16_LE - | aplay -D duplex - & echo $! > ~/.audio/PID | echo "1" > ~/.audio/status)
		fi
fi

if test $(cat ~/.audio/incoming) == 0
	then
		if test $(cat ~/.audio/status) == 0
			then
				echo "Already stopped."
			else
				$(sudo kill $(cat ~/.audio/PID) | echo "0" > ~/.audio/status)
		fi
fi
